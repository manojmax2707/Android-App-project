package com.example.connect_firebase

class Employee {
    var empno = 0
    var empname = ""
    var empsal = 0

    constructor(emp_no:Int, emp_name:String, emp_sal:Int) {

        this.empno = emp_no
        this.empname = emp_name
        this.empsal = emp_sal
    }

}