package com.example.connect_firebase

data class User(val empNo: String, val empName: String? = null, val empSal: String){

}
