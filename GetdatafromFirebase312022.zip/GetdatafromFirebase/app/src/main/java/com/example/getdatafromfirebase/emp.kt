package com.example.getdatafromfirebase

data class emp(val empNo : String? = null, val empName : String? = null, val phoneNo : String? = null)
