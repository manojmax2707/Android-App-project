package com.example.listactivity

data class User(var name : String, var lastMessage : String, var lastMsgTime : String,
var phoneNo : String, var hobby : String, var country : String, val imageId: Int )

