package com.example.retrofittry

class Constance {

    companion object{
        const val BASE_URL = "https://jsonplaceholder.typicode.com"
    }
}